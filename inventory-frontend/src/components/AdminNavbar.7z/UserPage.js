import React from 'react';

function UserPage() {
  return (
    <div>
      <h1>Bienvenido, Usuario</h1>
      <p>Esta es la página exclusiva para usuarios.</p>
    </div>
  );
}

export default UserPage;
