// src/App.jsx
import React from "react";
import { Routes, Route } from "react-router-dom";
import Login from "./components/auth/Login";

// Componentes de ejemplo para rutas
function AdminPage() {
  return <div className="p-10 text-center text-2xl">¡Bienvenido Admin!</div>;
}

function UserPage() {
  return <div className="p-10 text-center text-2xl">¡Bienvenido Usuario!</div>;
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/login" element={<Login />} />
      <Route path="/admin" element={<AdminPage />} />
      <Route path="/user" element={<UserPage />} />
    </Routes>
  );
}
