package com.inventory.repository;

import com.inventory.model.Eventos_Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EventosDeProductoRepository extends JpaRepository<Eventos_Producto, Long> {
    List<Eventos_Producto> findByUsuarioUsername(String username);
    List<Eventos_Producto> findByProductoId(Long productoId);
    List<Eventos_Producto> findByTipoDeEventoId(Long tipoDeEventoId);
}
