package com.inventory.repository;

import com.inventory.model.Tipo_Evento;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TiposDeEventoRepository extends JpaRepository<Tipo_Evento, Long> {
    Optional<Tipo_Evento> findByNombre(String nombre);
}