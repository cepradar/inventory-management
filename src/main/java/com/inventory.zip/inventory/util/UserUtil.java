package com.inventory.util;

public class UserUtil {
    
}
