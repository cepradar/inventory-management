package com.inventory.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.inventory.model.Cliente;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data // Genera getters, setters, toString, equals, hashCode
@NoArgsConstructor // Constructor sin argumentos
@AllArgsConstructor // Constructor con todos los campos
public class ClienteDto {

    private String id;
    private String nit;
    private String categoryId;
    private String tipoDocumentoId;
    private String nombre;
    private String telefono;
    private String direccion;
    private Boolean activo;

    // Constructor específico para deserialización JSON
    @JsonCreator
    public ClienteDto(
            @JsonProperty("id") String id,
            @JsonProperty("nit") String nit,
            @JsonProperty("categoryId") String categoryId,
            @JsonProperty("tipoDocumentoId") String tipoDocumentoId,
            @JsonProperty("nombre") String nombre,
            @JsonProperty("telefono") String telefono,
            @JsonProperty("direccion") String direccion,
            @JsonProperty("activo") Boolean activo) {
        this.id = id;
        this.nit = nit;
        this.categoryId = categoryId;
        this.tipoDocumentoId = tipoDocumentoId;
        this.nombre = nombre;
        this.telefono = telefono;
        this.direccion = direccion;
        this.activo = activo;
    }

    // Método utilitario para convertir DTO a entidad
    public static Cliente toCliente(ClienteDto clienteDto) {
        Cliente cliente = new Cliente();
        cliente.setDireccion(clienteDto.getDireccion());
        cliente.setNit(clienteDto.getNit());
        cliente.setNombre(clienteDto.getNombre());
        cliente.setTelefono(clienteDto.getTelefono());
        // Podrías agregar setActivo si tu entidad Cliente lo tiene
        return cliente;
    }
}
