package com.inventory.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "eventos_producto")
public class Eventos_Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_username", nullable = false)
    private User usuario;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tipoDeEvento_id", nullable = false)
    private Tipo_Evento tipoDeEvento;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "producto_id", nullable = false)
    private Product producto;

    @Column(nullable = false)
    private LocalDateTime fechaEvento;

    // Constructor vacío requerido por JPA
    public Eventos_Producto() {}

    public Eventos_Producto(Long id, User usuario, Tipo_Evento tipoDeEvento, Product producto,
            LocalDateTime fechaEvento) {
        this.id = id;
        this.usuario = usuario;
        this.tipoDeEvento = tipoDeEvento;
        this.producto = producto;
        this.fechaEvento = fechaEvento;
    }



    public User getUsuario() {
        return usuario;
    }

    public void setUsuario(User usuario) {
        this.usuario = usuario;
    }

    public Tipo_Evento getTipoDeEvento() {
        return tipoDeEvento;
    }

    public void setTipoDeEvento(Tipo_Evento tipoDeEvento) {
        this.tipoDeEvento = tipoDeEvento;
    }

    public Product getProducto() {
        return producto;
    }

    public void setProducto(Product producto) {
        this.producto = producto;
    }

    public LocalDateTime getFechaEvento() {
        return fechaEvento;
    }

    public void setFechaEvento(LocalDateTime fechaEvento) {
        this.fechaEvento = fechaEvento;
    }
}
